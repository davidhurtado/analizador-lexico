
function ltrim(str, charlist) {

    charlist = !charlist ? ' \\s\u00A0' : (charlist + '')
            .replace(/([\[\]\(\)\.\?\/\*\{\}\+\$\^\:])/g, '$1');
    var re = new RegExp('^[' + charlist + ']+', 'g');
    return (str + '')
            .replace(re, '');
}



// Creacion de los arrays (Librerias)
var librerias = ['string', 'struct', 'difflib', 'stringprep', 'fpformat',
    'StringIO', 'cStringIO', 'textwrap', 'codecs', 'unicodedata', 'datetime', 'calendar',
    'calendar', 'collections', 'heapq', 'bisect', 'array', 'sched', 'fileinput', 'queue',
    'weakref', 'stat', 'filecmp', 'tempfile', 'types', 'numbers', 'copy', 'math', 'cmath',
    'decimal', 'fractions', 'random', 'itertools', 'functools', 'operator', 'glob', 'fnmatch',
    'linecache', 'shutil', 'pickle', 'macpath', 'copyreg', 'shelve', 'marshal', 'dbm', 'sqlite3',
    'zlib', 'gzip', 'bz2', 'zipfile', 'tarfile', 'csv', 'configparser', 'netrc', 'xdrlib',
    'plistlib', '_sha1', 'md5', 'hmac', 'hashlib', 'time', 'argparse', 'optparse', 'getopt',
    'logging', 'getpass', 'curses', 'platform', 'errno', 'ctypes', 'select', 'threading', '_thread',
    'dummy_threading', '_dummy_thread', 'multiprocessing', 'mmap', 'rlcompleter', 'subprocess',
    'socket', 'ssl', 'signal', 'asyncore', 'asynchat', 'email', 'json', 'mailcap', 'mailbox', 'mimetypes',
    'base64', 'binhex', 'binascii', 'quopri', 'html', 'xml', 'webbrowser', 'cgi', 'cgitb', 'wsgiref',
    'urllib', 'urllib2', 'httplib', 'http', 'ftplib', 'poplib', 'imaplib', 'nntplib', 'smtplib', 'smtpd',
    'telnetlib', 'uuid', 'socketserver', 'BaseHTTPServer', 'SimpleHTTPServer', 'CGIHTTPServer', 'Cookie',
    'cookielib', 'xmlrpc', 'SimpleXMLRPCServer', 'DocXMLRPCServer', 'audioop', 'imageop', 'aifc', 'sunau',
    'wave', 'chunk', 'colorsys', 'imghdr', 'sndhdr', 'ossaudiodev', 'gettext', 'locale', 'cmd', 'shlex',
    'tkinter', 'ttk', 'Tix', 'ScrolledText', 'turtle', 'pydoc', 'doctest', 'unittest', 'test', 'bdb',
    'pdb', 'hotshot', 'timeit', 'trace', 'distutils', 'ensurepip', 'sys', 'sysconfig', '__builtin__',
    'warnings', 'contextlib', 'abc', 'atexit', 'traceback', 'inspect', 'site', 'user', 'fpectl',
    'code', 'codeop', 'rexec', 'Bastion', 'importlib', 'imputil', 'zipimport', 'pkgutil', 'modulefinder',
    'runpy', 'parser', 'symtable', 'symbol', 'token', 'keyword', 'tokenize', 'tabnanny', 'pyclbr',
    'py_compile', 'compileall', 'pickletools', 'formatter', 'msilib', 'msvcrt', '_winreg', 'winsound',
    'posix', 'pwd', 'spwd', 'grp', 'crypt', 'dl', 'termios', 'tty', 'pty', 'fcntl', 'pipes', 'posixfile',
    'resource', 'syslog', 'commands', 'MaccOS', 'macostools', 'findertools'
];

// Palabras reservadas
var PalabrasRsvs = /\b((__date__)|(eval)|(or)|(none)|(reverse)|(self)|(del)|(elif)|(else)|(except)|(len)|(print)|(end)|(input)|(in)|(range)|(exec)|(finally)|(for)|(from)|(global)|(if)|(import)|(lambda)|(not)|(pass)|(print)|(raise)|(return)|(try)|(while)|(local)|(False)|(True)|(__main__)|(__author__)|(__init__)|(int)|(float)|(bool)|(continue)|(def)|(class)|(abstract)|(assert)|(and)|(boolean)|(break)|(byte)|(strinctfp)|(case)|(catch)|(char)|(class)|(const)|(continue)|(default)|(double)|(else)|(enum)|(extends)|(false)|(final)|(finally)|(for)|(goto)|(implements)|(import)|(instanceof)|(int)|(interface)|(long)|(native)|(new)|(null)|(package)|(private)|(protected)|(public)|(return)|(short)|(static)|(super)|(swich)|(synchtonized)|(this)|(threadsafe)|(throw)|(throws)|(true)|(try)|(void)|(while)|(cast)|(operator)|(future)|(outer)|(generic)|(rest)|(inner)|(var)|(byvalue)|(if))(?=)\b/gi;
// Operadores de comparacion
var opComp = [[/\=\=/g, "=="], [/\!\=/g, "!="], [/\<\>/g, "<>"], [/\>/g, ">"], [/\</g, "<"], [/\<\=/g, "<="], [/\>\=/g, ">="]];
// Operadores de asignacion
var opAsign = /([^!a-z0-9][+|-|*]?[=])|\b=\b/gi;
// Operadores aritmeticos
var opArit = /[+\-\*\/\**\^\%]/gi;
// Simbolos
var Simbolos = /[!\$\&\(\)\?\¿\[\]\{\}\:\;\.\,\@]/gi;
// Consttantes
var Constantes = /[+|-]?[0-9]*\d(?=)\b/g;
// Cadenas
var Cadenas = /"([^"]*)"|'([^']*)'/g;
// Identificcadores
var Ident = /\b[_a-z][a-z|0-9|_]*[[0-9]*]*/gi;
//Comentarios
var Coment = /#()/g;

var rr = '';
var space = '';
var tt = '';
PalRes = 0;
lib = 0;
opas = 0;
opsi = 0;
opco = 0;
sim = 0;
con = 0;
idn = 0;
cad = 0;
coment = 0;
function processFiles(files) {
    var file = files[0];
    var reader = new FileReader();
    reader.onload = function (e) {

        var output = document.getElementById("fileOutput");
        output.textContent = e.target.result;
        var content = output.textContent;
        content = content.toString();
        var reg = /\s/g;

        lineas = content.split("\n");
        spx = content.split(reg);
        procesar();
        var read = document.getElementById("fileRead");
        read.textContent = e.target.result;

        var tot = document.getElementById("total");
        tot.textContent = e.target.result;

        $('#fileOutput').html(rr);
        $('#fileRead').html(space);
        $('#total').html(tt);


    };
    reader.readAsText(file);
}
function processText(codigo) {
    var output = document.getElementById("fileOutput");
    //output.textContent = e.target.result;
    var content = output.textContent;
    content = codigo;
    var reg = /\s/g;

    lineas = content.split("\n");
    spx = content.split(reg);
    console.log(codigo);
    procesar();
    $('#fileOutput').html(rr);
    $('#fileRead').html(space);
    $('#total').html(tt);

}

function procesar() {
    rr = '';
    space = '';
    tt = '';
    PalRes = 0;
    lib = 0;
    opas = 0;
    opsi = 0;
    opco = 0;
    sim = 0;
    con = 0;
    idn = 0;
    cad = 0;
    coment = 0;
    rr += ("\n<h2 align='center'>C&Oacute;DIGO FUENTE</h2>") + "<br>";
    space += ("\n<h2 align='center'>AN&Aacute;LISIS L&Eacute;XICO</h2>") + "<br>";

    for (i = 0; i < lineas.length; i++) {

        lineaActual = ltrim(lineas[i]);
        rr += lineas[i] + "<br>";
        var lineaPalRes = lineaActual;
        if (lineaActual.search(Coment) === -1) {
            if (lineaActual.search(Cadenas) !== -1) {
                space += "linea[" + (i + 1) + "] Cadena -> " + lineaActual.match(Cadenas) + "<br>";
                var linChar = lineaActual.match(Cadenas);
                for (var lb = 0; lb < linChar.length; lb++) {
                    cad++;
                    lineaPalRes = lineaPalRes.replace(lineaActual.match(Cadenas)[lb], "");
                }
            }

            if (lineaPalRes.search(PalabrasRsvs) !== -1) {
                PalRes += lineaPalRes.match(PalabrasRsvs).length;
                space += "linea[" + (i + 1) + "] Palabra Reservada -> " + (lineaPalRes.match(PalabrasRsvs)) + "<br>";
            }
            /* Linea sin tomar encuenta los comentarios*/
            lineaActual = lineaPalRes;
            for (var lb = 0; lb < librerias.length; lb++) {
                if (lineaActual.search(librerias[lb]) !== -1) {
                    lib++;
                    space += "linea[" + (i + 1) + "] Libreria -> " + (librerias[lb]) + "<br>";
                }
            }
            for (var opcom = 0; opcom < opComp.length; opcom++) {
                if (lineaActual.search(opComp[opcom][0]) !== -1) {
                    opco++;
                    space += "linea[" + (i + 1) + "] Operador de comparacion -> " + (opComp[opcom][1]) + "<br>";
                }
            }
            if (lineaActual.search(opArit) !== -1) {
                opas += lineaActual.match(opArit).length;
                space += "linea[" + (i + 1) + "] Operador Aritmetico -> " + (lineaActual.match(opArit)) + "<br>";
            }

            if (lineaActual.search(opAsign) !== -1) {
                opsi += lineaActual.match(opAsign).length;
                space += "linea[" + (i + 1) + "] Operador de Asignacion ->" + (lineaActual.match(opAsign)) + "<br>";
            }
            if (lineaActual.search(Simbolos) !== -1) {
                sim += lineaActual.match(Simbolos).length;
                space += "linea[" + (i + 1) + "] Simbolo -> " + (lineaActual.match(Simbolos)) + "<br>";
            }
            if (lineaActual.search(Constantes) !== -1) {
                con += lineaActual.match(Constantes).length;
                space += "linea[" + (i + 1) + "] Constante -> " + (lineaActual.match(Constantes)) + "<br>";
            }
            if (lineaActual.search(Ident) !== -1) {
                space += "linea[" + (i + 1) + "] Identificador -> ";
                for (var iden = 0; iden < lineaActual.match(Ident).length; iden++) {

                    if (lineaActual.match(Ident)[iden].search(PalabrasRsvs) === -1) {
                        idn++;
                        space += lineaActual.match(Ident)[iden] + ",";
                    }

                }
                space += "<br>";
            }
        }
        if (lineaActual.charAt(0) === '#') {
            space += "linea[" + (i + 1) + "] Comentario -> " + lineaActual + "<br>";
            coment++;
        }
    }

    tt += ("\n\n  <h2 align='center'>CANTIDAD DE LEXEMAS PARA CADA TOKEN </h2>  \n\n") + "<br>";
    tt += ("Existen  " + PalRes + "  Palabras reservadas") + "<br>";
    tt += ("Existen  " + lib + "  Librerias") + "<br>";
    tt += ("Existen  " + opas + "  Operadores aritmeticos") + "<br>";
    tt += ("Existen  " + opsi + "  Operadores de asignacion") + "<br>";
    tt += ("Existen  " + opco + "  Operadores de comparacion") + "<br>";
    tt += ("Existen  " + sim + "  Simbolos") + "<br>";
    tt += ("Existen  " + con + "  Constantes") + "<br>";
    tt += ("Existen  " + idn + "  Identificadores") + "<br>";
    tt += ("Existen  " + cad + "  Cadenas") + "<br>";
    tt += ("El codigo tiene  " + coment + "  Comentarios");
}