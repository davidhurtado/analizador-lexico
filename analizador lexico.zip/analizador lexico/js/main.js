// Creación del módulo
var angularRoutingApp = angular.module('angularRoutingApp', ['ngRoute']);
// Configuración de las rutas
angularRoutingApp.config(function ($routeProvider) {

    $routeProvider
            .when('/', {
                templateUrl: 'pages/selectfile.html',
                controller: 'mainController'
            })
            .when('/ingresocodigo', {
                templateUrl: 'pages/ingresocodigo.html',
                controller: 'ingresoController'
            })
            .otherwise({
                redirectTo: '/'
            });
});


angularRoutingApp.controller('mainController', function ($scope) {
    //$scope.message = 'Hola, Mundo!';
});

angularRoutingApp.controller('ingresoController', function ($scope) {

    $scope.message = 'Esta es la página ingreso';
});

